import math
import sys

from PyQt5 import uic
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QLabel, QWidget
from PyQt5.QtWidgets import QMainWindow
from math import sin


class FirstWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Scalc.ui', self)
        self.setWindowTitle('Калькулятор площадей')

        self.pixmap = QPixmap('треугольник.jpg')
        self.image = QLabel(self)
        self.image.move(130, 150)
        self.image.resize(300, 200)
        self.image.setPixmap(self.pixmap)

        self.pixmap = QPixmap('параллелограмм.jpg')
        self.image1 = QLabel(self)
        self.image1.move(610, 150)
        self.image1.resize(400, 200)
        self.image1.setPixmap(self.pixmap)

        self.pixmap = QPixmap('круг.jpg')
        self.image2 = QLabel(self)
        self.image2.move(170, 425)
        self.image2.resize(250, 250)
        self.image2.setPixmap(self.pixmap)

        self.pixmap = QPixmap('трапеция.jpg')
        self.image3 = QLabel(self)
        self.image3.move(620, 450)
        self.image3.resize(340, 210)
        self.image3.setPixmap(self.pixmap)

        self.Circle.clicked.connect(self.circle)
        self.Triangle.clicked.connect(self.triangle)
        self.Trapezoid.clicked.connect(self.trapezoid)
        self.Parallelogram.clicked.connect(self.parallelogram)

        self.extriangle = Triangle()
        self.excircle = Circle()
        self.extrapezoid = Trapezoid()
        self.exparallelogram = Parallelogram()

    def triangle(self):
        self.close()
        self.extriangle.show()

    def circle(self):
        self.close()
        self.excircle.show()

    def trapezoid(self):
        self.close()
        self.extrapezoid.show()

    def parallelogram(self):
        self.close()
        self.exparallelogram.show()

class Triangle(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Triangle.ui', self)
        self.exraznostor = Raznostor()
        self.exravnostor = Ravnostor()
        self.expryamoug = Pryamoug()
        self.Back.clicked.connect(self.back)
        self.Raznostor.clicked.connect(self.raznostor)
        self.Pryamoug.clicked.connect(self.pryamoug)
        self.Ravnostor.clicked.connect(self.ravnostor)

    def back(self):
        self.close()
        self.back = FirstWindow()
        self.back.show()

    def raznostor(self):
        self.close()
        self.exraznostor.show()

    def pryamoug(self):
        self.close()
        self.expryamoug.show()

    def ravnostor(self):
        self.close()
        self.exravnostor.show()


class Raznostor(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("Raznostor.ui", self)
        self.Back.clicked.connect(self.back)
        self.Calc.clicked.connect(self.calc)

    def calc(self):
        if self.radioButton.isChecked():
            a1 = float(self.A1.text())
            b1 = float(self.B1.text())
            c1 = float(self.C1.text())
            p = (a1 + b1 + c1) / 2
            s1 = (p * (p - a1) * (p - b1) * (p - c1)) ** 0.5
            self.S1.setText(str(s1))

        if self.radioButton_2.isChecked():
            a2 = float(self.A2.text())
            h2 = float(self.H2.text())
            s2 = 0.5 * a2 * h2
            self.S2.setText(str(s2))

        if self.radioButton_3.isChecked():
            a3 = float(self.A3.text())
            b3 = float(self.B3.text())
            aa3 = float(self.AA3.text())
            cof = 1
            if self.radioButton_6.isChecked():
                cof = 1
            if self.radioButton_7.isChecked():
                cof = math.pi / 180
            s3 = 0.5 * a3 * b3 * sin(aa3 * cof)
            self.S3.setText(str(s3))

        if self.radioButton_4.isChecked():
            r4 = float(self.R4.text())
            p4 = float(self.P4.text())
            s4 = r4 * p4
            self.S4.setText(str(s4))

        if self.radioButton_5.isChecked():
            r5 = float(self.R5.text())
            a5 = float(self.A5.text())
            b5 = float(self.B5.text())
            c5 = float(self.C5.text())
            s5 = (a5 * b5 * c5) / (4 * r5)
            self.S5.setText(str(s5))

    def back(self):
        self.close()
        self.back = Triangle()
        self.back.show()


class Ravnostor(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Ravnostor.ui', self)
        self.Calc.clicked.connect(self.calc)
        self.Back.clicked.connect(self.back)

    def calc(self):
        a = float(self.Aa.text())
        self.Sa.setText(str((a ** 2 * 3 ** 0.5) / 4))

    def back(self):
        self.close()
        self.back = Triangle()
        self.back.show()

class Pryamoug(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Pryamoug.ui', self)
        self.Back.clicked.connect(self.back)
        self.Calc.clicked.connect(self.calc)

    def calc(self):
        a = float(self.Aa.text())
        b = float(self.Bb.text())
        self.Ss.setText(str(0.5 * a * b))

    def back(self):
        self.close()
        self.back = Triangle()
        self.back.show()

class Circle(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Circle.ui', self)
        self.Calc.clicked.connect(self.calc)
        self.Back.clicked.connect(self.back)

    def calc(self):
        sr = float(self.Sr.text())
        self.Sokr.setText(str(2 * (sr ** 2)) + "π")

    def back(self):
        self.close()
        self.back = FirstWindow()
        self.back.show()



class Trapezoid(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Trapezoid.ui', self)
        self.Back.clicked.connect(self.back)
        self.Calc.clicked.connect(self.calc)

    def back(self):
        self.close()
        self.back = FirstWindow()
        self.back.show()

    def calc(self):
        if self.radioButton.isChecked():
            a1 = float(self.Aa.text())
            b1 = float(self.Bb.text())
            h1 = float(self.h1.text())
            self.S1.setText(str((a1 + b1) * h1 / 2))
        if self.radioButton_2.isChecked():
            h2 = float(self.h2.text())
            m2 = float(self.Mm.text())
            self.S2.setText(str(m2 * h2))


class Parallelogram(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Parallelogram.ui', self)
        self.Back.clicked.connect(self.back)
        self.Calc.clicked.connect(self.calc)

    def back(self):
        self.close()
        self.back = FirstWindow()
        self.back.show()

    def calc(self):
        a = float(self.Aa.text())
        h = float(self.Hh.text())
        self.Ss.setText(str(a * h))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    fw = FirstWindow()
    fw.show()
    sys.exit(app.exec_())
